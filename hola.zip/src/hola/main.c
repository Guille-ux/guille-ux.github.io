#include <stdio.h>
#include "../../include/hola/hola.h"

void greetings(const char *name) {
	printf(MESSAGE, name);
}
