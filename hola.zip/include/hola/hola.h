#ifndef HOLA_H
#define HOLA_H

#define MESSAGE "Hello, %s"

void greetings(const char *name);

#endif
