gcc -o morse-curse morse-curse.c -lncurses -L../../libmorse/lib/ -lmorse
cp morse-curse ../builded/
