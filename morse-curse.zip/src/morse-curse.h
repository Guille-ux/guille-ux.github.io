#ifndef SCHEDULE_MAKER_H
#define SCHEDULE_MAKER_H

#include <stdbool.h> // Para usar el tipo 'bool'
#include <stddef.h>
#include <stdint.h>

void down_print_bar(char color_attribute, char *text);
void up_print_bar(char color_attribute, char *text); 
void init_scheduler_colors();
unsigned char get_w_mid();
unsigned char get_h_mid();
int get_cur_x();
int get_cur_y();
void displace_cur_x(int displacement);
void fill_line(int y);
void mvx(int x);
void mvy(int y);
void clean(char color);

#endif
