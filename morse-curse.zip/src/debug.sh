bash build.sh
./morse-curse
