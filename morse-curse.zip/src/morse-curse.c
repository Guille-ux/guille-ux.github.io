#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ncurses.h>
#include "morse-curse.h"
#include "../../libmorse/src/morse.h"

char current=18;

int main(int argc, const char argv[]) {
  char buffer[256];
  char obuff[32];
  initscr();
  noecho();
  curs_set(0);
  if (has_colors()) {
    init_scheduler_colors();  
  }
  down_print_bar(12, "");
  mvx(get_w_mid()-7); // menos 7 porque es la mitad de la longitud
  up_print_bar(12, "Morse Curse");
  attron(COLOR_PAIR(2));
  move(1, 0);
  printw("Type 'help' to get some help with commands.\n");
  printw("Type Anything to Continue\n");
  move(LINES-1, 0);

  getch();

  current=18;
  clean(2);

  attron(COLOR_PAIR(18) | A_BOLD);

  refresh();

  echo();
  // comandos
  curs_set(1);
  int mcursor=1;
  Character buff;
  while (1) {
    if (mcursor>LINES-1) {
      clean(2);
      mcursor=1;
    }
    move(LINES-1, 0);
    fill_line(LINES-1);
    printw(">: ");
    getnstr(buffer, 255);
    if (strcmp(buffer, "quit")==0) {
      break;
    } else if (strcmp(buffer, "exit")==0) {
      break;
    } else if (strcmp(buffer, "translate")==0) {
      move(LINES-1, 0);
      fill_line(LINES-1);
      printw("ASCII text >: ");
      getnstr(buffer, 255);
      mvy(mcursor);
      attroff(A_BOLD);
      attron(COLOR_PAIR(3));
      printw("[+] : ");
      for (unsigned long int i=0; i<strlen(buffer);i++) {
        buff=ascii2character(buffer[i]);
        character2morse(buff, obuff);
        printw("%s", obuff);
        if ((i+1)<strlen(buffer)) {
          printw("/");
        }
      }
      mcursor++;
      attron(COLOR_PAIR(18) | A_BOLD);
    } else if (strcmp(buffer, "help")==0){
      clean(2);
      attron(COLOR_PAIR(2) | A_BOLD);
      mvy(1);
      printw("[ --- Help Message --- ] \n");
      attroff(A_BOLD);
      attron(COLOR_PAIR(2));
      printw("[+] - exit      : Exit from Morse Curse \n");
      printw("[+] - quit      : Exit from Morse Curse \n");
      printw("[+] - help      : Displays this help message \n");
      printw("[+] - clear     : Cleans the display \n");
      printw("[+] - translate : Translate to morse from ascii\n");
      mcursor += 6;
      attron(COLOR_PAIR(18) | A_BOLD);
    } else if (strcmp(buffer, "clear")==0) {
      clean(2);
      attron(A_BOLD);
      mcursor=1;
    } else {
      mvx(0);
      attron(COLOR_PAIR(13) | A_BOLD);
      printw("ERROR, Unknown Command, press something to continue.");
      noecho();
      getch();
      echo();
      attron(COLOR_PAIR(18) | A_BOLD);
    }
    refresh();
  }

  endwin();
  return 0;
}

void down_print_bar(char color_attribute, char *text) {
  attron(COLOR_PAIR(color_attribute));
  int x=get_cur_x();
  fill_line(LINES-1);
  move(LINES-1, x);
  printw(text);
}

void up_print_bar(char color_attribute, char *text) {
  attron(COLOR_PAIR(color_attribute));
  int x=get_cur_x();
  fill_line(0);
  move(0, x);
  printw(text);
}

void init_scheduler_colors() {
  start_color();
  init_pair(1, COLOR_WHITE, COLOR_BLACK);
  init_pair(2, COLOR_CYAN, COLOR_BLACK);
  init_pair(3, COLOR_GREEN, COLOR_BLACK);
  init_pair(4, COLOR_YELLOW, COLOR_BLACK);
  init_pair(5, COLOR_RED, COLOR_BLACK);
  init_pair(6, COLOR_BLACK, COLOR_WHITE);
  init_pair(7, COLOR_BLUE, COLOR_BLACK);
  init_pair(8, COLOR_WHITE, COLOR_BLUE);
  init_pair(9, COLOR_MAGENTA, COLOR_BLACK);
  init_pair(10, COLOR_WHITE, COLOR_BLACK);
  init_pair(11, COLOR_BLACK, COLOR_CYAN);
  init_pair(12, COLOR_BLACK, COLOR_RED);
  init_pair(13, COLOR_WHITE, COLOR_RED);
  init_pair(14, COLOR_BLACK, COLOR_GREEN);
  init_pair(15, COLOR_WHITE, COLOR_GREEN);
  init_pair(16, COLOR_BLACK, COLOR_YELLOW);
  init_pair(17, COLOR_CYAN, COLOR_RED);
  init_pair(18, COLOR_YELLOW, COLOR_RED);
}

unsigned char get_w_mid() {
  return COLS / 2;
}

unsigned char get_h_mid() {
  return LINES / 2;
}

int get_cur_x() {
  return getcurx(stdscr);
}

int get_cur_y() {
  return getcury(stdscr);
}

void displace_cur_x(int displacement) {
  int y=getcury(stdscr);
  int x=getcurx(stdscr);
  move(y, x + displacement);
}

void fill_line(int y) {
  mvhline(y, 0, ' ', COLS);
}

void mvx(int x) {
  int y=get_cur_y();
  move(y, x);
}

void mvy(int y) {
  int x=get_cur_x();
  move(y, x);
}

void clean(char color) {
  attron(COLOR_PAIR(color));
  for (int i=1; i<LINES-1; i++) {
    fill_line(i);
  }
  attron(COLOR_PAIR(current));
}
