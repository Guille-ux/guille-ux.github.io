#ifndef LIBCSTWO
#define LIBCSTWO

#endif
