#ifndef LIBCSTWO
#define LIBCSTWO

#include "string.h"
#include "io.h"
#include "display.h"
#include "vga.h"

#endif
