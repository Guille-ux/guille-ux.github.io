#ifndef LIBCSTWO
#define LIBCSTWO

#include "string.h"
#include "vga.h"
#include "io.h"
#include "display.h"

#endif
