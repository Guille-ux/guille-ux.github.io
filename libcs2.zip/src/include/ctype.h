#ifndef CTYPE_H
#define CTYPE_H

int isspace(int c);
int isalpha(int c);
int isdigit(int c);
int isalnum(int c); // isalpha || isdigit

#endif
