#ifndef PRINTF_H
#define PRINTF_H

int kprintf(const char *format, ...);

#endif
