# LibCS2
*libcs2 is an standalone standard library for c*
