#ifndef NATIVES_H
#define NATIVES_H

// Add forward declarations of your native funcs here


#endif
