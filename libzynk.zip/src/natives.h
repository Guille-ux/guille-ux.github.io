#ifndef NATIVES_H
#define NATIVES_H
#include "zynk.h"
// Add forward declarations of your native funcs here
void init_native_funcs(ZynkEnv *env);
Value libzynk_len(ZynkEnv *env, ZynkArray *args);
Value libzynk_push(ZynkEnv *env, ZynkArray *args);
Value libzynk_pop(ZynkEnv *env, ZynkArray *args);
Value libzynk_get_index(ZynkEnv *env, ZynkArray *args);
Value libzynk_set_index(ZynkEnv *env, ZynkArray *args);

#endif
