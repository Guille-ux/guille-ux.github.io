make

cp libzynk.a ../
