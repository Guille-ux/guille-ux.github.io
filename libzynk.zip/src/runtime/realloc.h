#ifndef ZYNK_REALLOC_H
#define ZYNK_REALLOC_H

#include "../common.h"
#include "../zynk.h"
#include "memory.h"
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

void* reallocate(uint8_t *pointer, size_t old_cap, size_t new_cap);

#endif
