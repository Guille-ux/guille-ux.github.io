#include "realloc.h"
#include "memory.h"
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

void* reallocate(uint8_t *pointer, size_t old_cap, size_t new_cap) {
  if (new_cap==0) free(pointer); return NULL;
  if (old_cap==0) return malloc(new_cap);
  if (old_cap==new_cap) return pointer;
  
  uint8_t *new_ptr=(uint8_t*)malloc(new_cap);
  if (new_ptr==NULL) return NULL;
  if (old_cap<new_cap) {
    memcpy(new_ptr, pointer, old_cap);
  } else {
    memcpy(new_ptr, pointer, new_cap);
  }
  free(pointer);
  return new_ptr;
}
