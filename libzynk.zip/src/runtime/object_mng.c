#include "object_mng.h"
#include "object_rf.h"
#include "realloc.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

static ZynkObj* create_base_zynk_obj(ObjType type) {

    ZynkObj* obj = (ZynkObj*)malloc(sizeof(ZynkObj));
    if (obj == NULL) return NULL; // Error

    obj->type = type;
    obj->ref_count = 1;
    return obj;
}

Value zynkCreateString(const char *str) {
  if (str==NULL) return zynkNull();
  
  size_t len = strlen(str);
  
  ZynkObj *obj = create_base_zynk_obj(ObjString);

  if (obj==NULL) return zynkNull();

  ZynkString *string=(ZynkString *)malloc(sizeof(ZynkString));
  if (string==NULL) {
    free((void *)obj);
    return zynkNull();
  }

  string->string=(char *)malloc(len+1);
  if (string->string==NULL) {
    free((void*)string);
    free((void*)obj);
    return zynkNull();
  }
  strncpy(string->string, str, len);
  string->string[len]='\0';
  string->len=len;

  obj->obj.string=string;

  Value ret;
  ret.type=ZYNK_OBJ;
  ret.as.obj=obj;
  return ret;
}

Value zynkCreateNativeFunction(const char *name, ZynkFuncPtr func_ptr) {

  ZynkObj *obj=create_base_zynk_obj(ObjNativeFunction);
  if (obj==NULL) {
    return zynkNull();
  }

  ZynkNativeFunction *z_func=(ZynkNativeFunction *)malloc(sizeof(ZynkNativeFunction));
  if (z_func==NULL) {
    free((void *)obj);
    return zynkNull();
  }

  z_func->name=name;
  z_func->func_ptr=func_ptr;

  obj->obj.native_func = z_func;

  Value ret;
  ret.type = ZYNK_OBJ;
  ret.as.obj=obj;
  return ret;
}

Value zynkCreateArray(size_t initial_capacity) {
  if (initial_capacity==0) initial_capacity=8; // minimum capacity

  ZynkObj* obj=create_base_zynk_obj(ObjArray);
  if (obj==NULL) return zynkNull();

  ZynkArray *z_arr=(ZynkArray *)malloc(sizeof(ZynkArray));
  if (z_arr==NULL) {
    free((void *)obj);
    return zynkNull();
  }

  z_arr->array=(Value*)malloc(sizeof(Value)*initial_capacity);
  if (z_arr->array==NULL) {
    free((void*)z_arr);
    free((void*)obj);
    return zynkNull();
  }

  z_arr->len=0;
  z_arr->capacity=initial_capacity;

  for (size_t i=0;i<initial_capacity;i++) {
    z_arr->array[i]=zynkNull();
  }

  obj->obj.array=z_arr;

  Value ret;
  ret.type=ZYNK_OBJ;
  ret.as.obj=obj;
  return ret;
}

bool zynkArrayGrow(ZynkArray* array_ptr, uint32_t amount) {
  size_t old_cap=array_ptr->capacity;
  size_t new_cap=old_cap+amount; // calculating new capacity

  if (new_cap < 8) new_cap=8; // minimum capacity

  Value *new_array_data=(Value*)reallocate(
      (uint8_t *)array_ptr->array,
      old_cap*sizeof(Value),
      new_cap*sizeof(Value)
  );

  // error?
  if (new_array_data==NULL) return false;

  array_ptr->array=new_array_data;
  array_ptr->capacity=new_cap;

  for (size_t i=old_cap;i<new_cap;i++) {
    array_ptr->array[i]=zynkNull();
  }

  return true;
}

Value zynkArrayPush(Value array_val, Value element_val) {
  if (array_val.type!=ZYNK_OBJ || array_val.as.obj==NULL || array_val.as.obj->type!=ObjArray) return zynkNull(); // that isn't a valid array!

  ZynkArray *arr_ptr=array_val.as.obj->obj.array;

  if (arr_ptr->len >= arr_ptr->capacity) {
    if (!zynkArrayGrow(arr_ptr, (arr_ptr->len - arr_ptr->capacity + 1))) return zynkNull();
  }
  arr_ptr->array[arr_ptr->len++]=zynk_retain(element_val);
  return array_val;
}
