#include "object_rf.h"
#include "types.h"
#include "../common.h"
#include <stdlib.h>

Value zynk_retain(Value val) {
  if (val.type!=ZYNK_OBJ) return val;
  if (val.as.obj==NULL) return zynkNull();
  val.as.obj->ref_count++;
  return val;
}

void zynk_release(Value val) {
  if (val.type!=ZYNK_OBJ) return;
  if (val.as.obj==NULL) return;
  val.as.obj->ref_count--;
  if (val.as.obj->ref_count == 0) {
    // eliminar individualmente
    switch (val.as.obj->type) {
      case (ObjString): freeString(val.as.obj->obj.string); break;
      case (ObjArray): freeArray(val.as.obj->obj.array); break;
    }

    // eliminar el obj en su conjunto
    free(val.as.obj);
  }
}

bool freeString(ZynkString *string) {
  if (string==NULL) return true;
  free(string->string);
  free(string);

  return true;
}

bool freeArray(ZynkArray *array) {
  if (array==NULL) return true;
  for (size_t i=0;i<array->len;i++) {
    switch (array->array[i].type) {
      case (ZYNK_OBJ): zynk_release(array->array[i]); break;
    }
  }
  free(array);
  return true;
}
