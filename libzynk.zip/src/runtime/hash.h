#ifndef ZYNK_HASH
#define ZYNK_HASH

#include <stdint.h>

uint32_t zynk_hash_string(const char *str);

#endif
