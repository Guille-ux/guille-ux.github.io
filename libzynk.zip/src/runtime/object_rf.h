#ifndef ZYNK_REFERENCE_COUNTER
#define ZYNK_REFERENCE_COUNTER

#include "types.h"
#include "../common.h"

Value zynk_retain(Value val);
void zynk_release(Value val);
bool freeString(ZynkString* string);
bool freeArray(ZynkArray* array);

#endif
