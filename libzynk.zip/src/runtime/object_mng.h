#ifndef ZYNK_OBJECT_MANAGER
#define ZYNK_OBJECT_MANAGER

#include "../zynk.h"
#include "../common.h"
#include "types.h"
#include "objects.h"
#include "realloc.h"
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include "assign.h"

Value zynkCreateNativeFunction(const char *name, ZynkFuncPtr func_ptr);
Value zynkCreateString(const char *str);
Value zynkCreateArray(size_t initial_capacity);
bool zynkArrayGrow(ZynkArray* array_ptr, uint32_t amount);
Value zynkArrayPush(Value array_val, Value element_val);


#endif
