// Code under LGPL
// Copyright 2025 Guillermo Leira Temes

#include "zynk_enviroment.h"
#include "../common.h"
#include "hash.h"
#include "memory.h"
#include "types.h"
#include "assign.h"


bool zynkEnvInit(ZynkEnv *env, size_t capacity, ZynkEnv *enclosing) {
  if (env==NULL) {
    return false; //no existe xD
  }
  env->enclosing=enclosing;
  return initZynkTable(env->local, capacity);
}

bool initZynkTable(ZynkEnvTable *table, size_t capacity) {
  if (table==NULL || table->entries==NULL) {
    return false; // no existe xD
  }
  table->capacity=capacity;
  for (size_t i=0;i<capacity;i++) {
    if (table->entries[i]==NULL){
      table->entries[i]=(ZynkEnvEntry *)malloc(sizeof(ZynkEnvEntry));
    }
    table->entries[i]->name=NULL;
    table->entries[i]->value=zynkNull();
  }
  return true;
}
bool freeZynkTable(ZynkEnvTable *table) {
  if (table==NULL || table->entries==NULL || table->capacity==0) {
    return false;
  } 
  for (size_t i=0;i<table->capacity;i++) {
    if (table->entries[i]==NULL) {
      continue;
    }
    if (table->entries[i]==NULL) continue;
    if (table->entries[i]->name==NULL) continue;
    free(table->entries[i]->name);
    free(table->entries[i]);
    table->entries[i]->name=NULL;
    table->entries[i]=NULL;
  }
  free(table->entries);
  free(table);
  return true;
}
bool zynkTableSet(ZynkEnv *env, const char *str, Value value) {
  if (env==NULL || str==NULL || env->local->capacity==0 || env->local==NULL) {
    return false;
  }
  ZynkEnvEntry *entry=zynkFindEntry(env, str, false);
  if (entry==NULL) {
    return false;
  }

  zynk_release(entry->value);

  zynk_retain(value);

  entry->value=value;
  return true;
}
bool zynkTableNew(ZynkEnv *env, const char *str, Value value) {
  if (env==NULL || str==NULL || env->local->capacity==0 || env->local->count == env->local->capacity || env->local==NULL) {
    return false;
  }
  ZynkEnvEntry *entry=zynkFindEntry(env, str, true);
  if (entry==NULL) {
    return false;
  } else if (entry->name==NULL) {
    char *name = (char *)malloc(strlen(str)+1);
    zynk_retain(value);
    entry->value = value;
    memcpy(name, str, strlen(str)+1);
    entry->name=name;
  } else {
    return false;
  }
  env->local->count++;
  return true;
}
Value zynkTableGet(ZynkEnv *env, const char *str) {
  if (env==NULL || str==NULL || env->local->capacity==0 || env->local==NULL) {
    return zynkNull();
  }
  ZynkEnvEntry *entry=zynkFindEntry(env, str, false);
  if (entry==NULL) {
    return zynkNull();
  }
  return entry->value;
}
bool zynkTableDelete(ZynkEnv *env, const char *str) {
  if (env==NULL || str==NULL || env->local->capacity==0 || env->local==NULL || env->local->entries==NULL) {
    return false;
  }
  ZynkEnvEntry *entry=zynkFindEntry(env, str, false);
  if (entry==NULL || entry->name == NULL) {
    return false;
  }
  free(entry->name);
  entry->name=NULL;
  zynk_release(entry->value);
  entry->value=zynkNull();
  env->local->count--;
  return true;
}
ZynkEnvEntry *zynkFindEntry(ZynkEnv *env, const char *key, bool niu) {
  size_t capacity=env->local->capacity;
  uint32_t index = zynk_hash_string(key) % capacity;
  uint32_t limit=index;
  for (;;) {
    ZynkEnvEntry *entry= env->local->entries[index];
    if (entry==NULL) {
      return NULL;
    } else if ((entry->name==NULL && niu) || strcmp(key, entry->name)==0) {
      return entry;
    }
    index = (index+1) % capacity;
    if (index==limit) {
      return NULL;
    }
  }
  if (env->enclosing==NULL) {
    return NULL;
  }
  return zynkFindEntry(env->enclosing, key, false);
}
